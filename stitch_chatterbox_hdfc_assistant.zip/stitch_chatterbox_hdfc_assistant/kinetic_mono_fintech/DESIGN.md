---
name: Kinetic Mono Fintech
colors:
  surface: '#f9f9f7'
  surface-dim: '#dadad8'
  surface-bright: '#f9f9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f2'
  surface-container: '#eeeeec'
  surface-container-high: '#e8e8e6'
  surface-container-highest: '#e2e3e1'
  on-surface: '#1a1c1b'
  on-surface-variant: '#44474a'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1ef'
  outline: '#74777a'
  outline-variant: '#c4c7ca'
  surface-tint: '#5a5f63'
  primary: '#2b3034'
  on-primary: '#ffffff'
  primary-container: '#41464a'
  on-primary-container: '#afb4b8'
  inverse-primary: '#c2c7cc'
  secondary: '#55615d'
  on-secondary: '#ffffff'
  secondary-container: '#d6e2dd'
  on-secondary-container: '#5a6561'
  tertiary: '#28322c'
  on-tertiary: '#ffffff'
  tertiary-container: '#3e4842'
  on-tertiary-container: '#abb6af'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe3e8'
  primary-fixed-dim: '#c2c7cc'
  on-primary-fixed: '#171c20'
  on-primary-fixed-variant: '#42474b'
  secondary-fixed: '#d9e5e0'
  secondary-fixed-dim: '#bdc9c4'
  on-secondary-fixed: '#131e1b'
  on-secondary-fixed-variant: '#3e4945'
  tertiary-fixed: '#dae5dd'
  tertiary-fixed-dim: '#bec9c1'
  on-tertiary-fixed: '#141e19'
  on-tertiary-fixed-variant: '#3f4943'
  background: '#f9f9f7'
  on-background: '#1a1c1b'
  surface-variant: '#e2e3e1'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.5rem
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  numeral-lg:
    fontFamily: Manrope
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  numeral-md:
    fontFamily: Manrope
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: 0.005em
  label-technical:
    fontFamily: Space Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: 0.04em
  label-code:
    fontFamily: Space Mono
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an intelligent, tactile, and restrained monochromatic visual environment for modern financial workflows. It draws direct inspiration from the hardware-first clarity of Nothing OS and the serene, non-judgmental editorial simplicity of Kuvera. Rather than relying on aggressive alerts or saturated signals, the interface communicates through mechanical precision, deliberate typography, and high-legibility spatial hierarchy.

The aesthetic fuses modern minimalism with subtle retro-technical accents—incorporating subtle dot-matrix field patterns, technical monospaced metadata, and structural 1px borders. Every surface feels physical yet weightless, engineered to reduce decision fatigue, cultivate composure, and foster financial mastery.

## Colors

The palette rejects pure digital black (#000000) and optical blue whites, relying instead on warm mineral tones and graphite balances:

- **Canvas & Layering**:
  - Main background: `#F8F8F6` provides a warm paper-matte foundation.
  - Secondary background (wells, tracks, segmented groups): `#F0F1EF`.
  - Cards & elevated interactive surfaces: `#FFFFFF`.
- **Typographic Hierarchy**:
  - Primary text: `#41464A` (refined deep charcoal for high readability without harsh contrast).
  - Secondary text: `#777E82` (graphite grey for descriptions and metadata).
  - Muted text: `#A0A6A8` (de-emphasized timestamps, placeholders, and inactive labels).
- **Accents & Delimiters**:
  - Hairline borders: `#E3E6E4`.
  - Dot matrix pattern grid: `#D8DCDA`.
  - Secondary accent: `#AAB6B1` (slate mineral for secondary badges and subtle indicators).
  - Soft sage accent: `#C5D0C8` (tactile muted sage for low-friction confirmation states and qualitative indicators).
  - CTA Interactive Core: `#41464A` fill paired strictly with `#F8F8F6` inverted label text.

## Typography

The typographic strategy balances human geometry, tabular data clarity, and machine-readable metadata:

- **Headings & Display**: Set in Plus Jakarta Sans. Wide, humanist-geometric proportions anchor titles, balances, and structural milestones.
- **Financial Balances & Tabular Figures**: Manrope is deployed with tabular figures (`font-variant-numeric: tabular-nums`) enabled across all ledger rows, balance summaries, and percentages to eliminate visual jitter across varying digits.
- **Interface & Prose**: Inter drives body copy, multi-line explanations, and transactional disclosures with neutral, high-density clarity.
- **Technical Badges & Meta Counters**: Space Mono is applied exclusively to status pills, timestamps, transaction hashes, ticker symbols, and secondary metric labels, reinforcing the hardware/Nothing OS inspiration.

## Layout & Spacing

The layout is built upon an 8pt architectural rhythm, utilizing a fluid grid nested within fixed edge constraints:

- **Desktop (>= 1024px)**: 12-column layout with 24px (`1.5rem`) gutters and a max canvas width of 1280px padded with a minimum 40px (`2.5rem`) outer margin.
- **Tablet (640px - 1023px)**: 8-column layout with 20px (`1.25rem`) gutters and 24px (`1.5rem`) margins.
- **Mobile (< 640px)**: 4-column layout with 16px (`1rem`) gutters and 16px (`1rem`) outer canvas margins.

Dot matrix fields (#D8DCDA) may be used as fixed-height horizontal section dividers or decorative empty-state frames, rendered strictly using an 8px grid interval to match the spacing cadence.

## Elevation & Depth

Visual hierarchy prioritizes surface tone and crisp borders over dramatic drop shadows:

- **Ground Layer (Canvas)**: Background tone `#F8F8F6` creates an immediate, tactile matte baseline.
- **Recessed Wells**: Inset containers, segmented control tracks, and code readouts adopt `#F0F1EF` with no shadow and an optional inset border of `#E3E6E4`.
- **Surface Elevation (Cards & Panels)**: High-priority cards sit on `#FFFFFF` enclosed in a 1px border of `#E3E6E4`. Shadows are nearly imperceptible: `0 1px 2px rgba(65, 70, 74, 0.04), 0 4px 12px rgba(65, 70, 74, 0.02)`.
- **Floating Overlays & Menus**: Modals and dropdowns feature `#FFFFFF` with a reinforced hairline border `#D8DCDA` and a soft ambient blur shadow: `0 12px 32px rgba(65, 70, 74, 0.08)`.

## Shapes

The shape scale relies on balanced, deliberate corner curvature between 8px and 16px:

- **Controls & Buttons**: Base border-radius of 8px (`0.5rem`), creating a precise handheld tool aesthetic.
- **Cards & Data Modules**: Outer containers adopt 12px (`0.75rem`) to 16px (`1rem`) depending on screen density, maintaining nested concentricity with their inner components.
- **Pills & Metas**: Technical badges and micro-chips utilize 6px to 8px rounded corners rather than full capsules to preserve a mechanical, hardware-printed identity.

## Components

- **Buttons**:
  - *Primary CTA*: `#41464A` solid fill, `#F8F8F6` text, 8px radius, no border. Subtle scale transition down to 0.98 on press.
  - *Secondary*: `#FFFFFF` fill with 1px `#E3E6E4` border and `#41464A` text. Hover shifts background to `#F0F1EF`.
  - *Ghost / Tertiary*: Transparent fill, `#777E82` text; hover reveals `#F0F1EF` background.
- **Cards & Containers**:
  - Flat `#FFFFFF` fill, 1px `#E3E6E4` hairline border, 12px to 16px corner radius.
  - Optional header zone delimited by a 1px horizontal `#E3E6E4` dividing border with 16px inner padding.
- **Chips & Status Tags**:
  - Rendered in Space Mono (`label-technical`).
  - Subtle slate variant: `#F0F1EF` background, `#41464A` text, 1px `#E3E6E4` border.
  - Sage accent variant: `#C5D0C8` at 30% alpha fill with solid `#41464A` text.
- **Input Fields**:
  - Default: `#FFFFFF` fill, 1px `#E3E6E4` border, 8px radius, text in `#41464A`, placeholder in `#A0A6A8`.
  - Focus state: Border transitions to `#41464A` with a subtle 2px ring in `#E3E6E4`. No blue or saturated outlines.
- **Checkboxes & Radios**:
  - Checked state uses `#41464A` fill with `#F8F8F6` icon. Unchecked uses `#FFFFFF` fill with 1px `#E3E6E4` perimeter.
- **Dot Matrix Canvas Dividers**:
  - Subtle repeating SVG radial dots (`#D8DCDA`, 1px radius, spaced every 8px) used for visual demarcation between overview cards and dense financial ledger tables.