---
name: Factual Wealth AI
colors:
  surface: '#f8f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#edeef0'
  surface-container-high: '#e7e8ea'
  surface-container-highest: '#e1e2e4'
  on-surface: '#191c1e'
  on-surface-variant: '#46464b'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f3'
  outline: '#77777b'
  outline-variant: '#c7c6cb'
  surface-tint: '#5e5e63'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1a1b1f'
  on-primary-container: '#838388'
  inverse-primary: '#c7c6cb'
  secondary: '#215db1'
  on-secondary: '#ffffff'
  secondary-container: '#74a5ff'
  on-secondary-container: '#003a7b'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#161b28'
  on-tertiary-container: '#7f8394'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3e2e7'
  primary-fixed-dim: '#c7c6cb'
  on-primary-fixed: '#1a1b1f'
  on-primary-fixed-variant: '#46464b'
  secondary-fixed: '#d7e2ff'
  secondary-fixed-dim: '#acc7ff'
  on-secondary-fixed: '#001a40'
  on-secondary-fixed-variant: '#004590'
  tertiary-fixed: '#dee2f4'
  tertiary-fixed-dim: '#c1c6d8'
  on-tertiary-fixed: '#161b28'
  on-tertiary-fixed-variant: '#414655'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e1e2e4'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies institutional precision, quiet authority, and computational clarity. Tailored for enterprise wealth discovery and algorithmic fund assistance, the interface departs from decorative consumer fintech tropes to present an analytical, calm workspace. 

The aesthetic synthesizes:
- **Ultra-Minimal Institutionalism:** Vast neutral canvas areas, restrained functional contrast, and meticulous editorial structuring.
- **Architectural Engineering:** Razor-thin structural borders, precise spatial grids, and rhythmic alignment that project stability and audit-ready integrity.
- **Subtle Telemetry Accents:** Discreet monospace indices, data markers, and soft dot-matrix grid motifs to convey real-time computation without cognitive noise or speculative flashiness.

## Colors

The palette relies on optical hierarchy anchored by deep carbon shades, layered against soft off-white canvas surfaces.

- **Primary Canvas (`#FBFBFB`) & Surface Containers (`#F6F7F9`, `#FFFFFF`):** High-clarity backdrops that eliminate visual fatigue and accentuate content scanning.
- **Charcoal (`#17181C`) & Graphite (`#2A2C33`):** High-density text, structural iconography, and definitive state representations.
- **Institutional Blue Accent (`#0D52A6`):** Reserved strictly for active indicators, verified data states, interactive highlights, and formal asset performance markers.
- **Structural Hairlines (`#E4E7EC`, `#D0D5DD`):** Neutral dividers ensuring absolute boundary clarity across modular panes.
- **Telemetry Muted (`#525766`, `#8A909E`):** Secondary metadata, timestamps, fund categorization tags, and regulatory citations.

## Typography

The typographic hierarchy distinguishes conversational language from hard financial telemetry.

- **Primary Interface Font:** Plus Jakarta Sans provides clean geometric clarity with open apertures, maximizing legibility in complex analytical prose, NAV breakdowns, and fund summaries.
- **Monospace Accent Font:** JetBrains Mono is assigned to verified facts, fund codes, ISINs, performance percentages, source attributions, and timestamp logs.
- **Hierarchy Rhythm:** Headlines remain low-contrast and tightly tracked. Body copy emphasizes comfortable reading distances with open line heights (`1.57` - `1.62` factor) to make technical mutual fund literature effortlessly consumable.

## Layout & Spacing

The spatial architecture maintains a structured reading column bounded by precise modular data gutters.

- **Desktop (1200px+):** Centered interactive dialogue console (max-width 840px) or asymmetrical two-column dashboard with a fixed query stage and persistent analytical side-panel (380px). Margins are generous (`3rem`) to emphasize calm focus.
- **Tablet (768px - 1199px):** Single-column layout with 24px margins; analytical sidebars collapse into slide-over metadata drawers.
- **Mobile (< 768px):** Compact fluid stage with 20px outer bounds; conversation bubbles extend full-width with 16px internal padding, reserving horizontal real estate for dense metric tables.
- **Micro Spacing Scale:** Built on a baseline 4px modular unit (`0.25rem` steps), enforcing mathematical predictability between labels, query inputs, and verification badges.

## Elevation & Depth

Visual hierarchy rejects exaggerated drop shadows and opaque blurs in favor of flat structural layers and crisp hairlines.

- **Base Canvas:** `#FBFBFB` represents the foundation tier.
- **Surface Elevation (Cards, Bubbles, Containers):** Pure `#FFFFFF` surfaces delineated by ultra-thin borders (`1px solid #E4E7EC`). 
- **Micro-Shadows:** Surfaces utilize a delicate ambient shadow strictly to separate floating chat inputs or contextual metric flyouts: `0px 1px 2px rgba(23, 24, 28, 0.04), 0px 4px 12px rgba(23, 24, 28, 0.03)`.
- **Dot-Matrix Grid Texture:** Canvas panels optionally carry a faint micro-dot matrix pattern (`#17181C` at 3% opacity on a 16px grid) to reinforce computational precision.

## Shapes

The design system maintains an architectural, soft-cornered vocabulary (`roundedness: 1`).

- **Structural Cards & Dialogue Blocks:** Calibrated to `0.5rem` (8px) corner radius, preserving a sturdy, editorial posture without appearing boxy or juvenile.
- **Telemetry Chips & Action Pills:** Full capsule rounding (`9999px`) is applied to verification chips, source pills, and suggested prompt buttons, providing touchable affordances.
- **Micro Elements:** Checkboxes, segment track buttons, and input boundaries employ `0.25rem` (4px) rounding for exact alignment alongside monospace telemetry.

## Components

### Buttons
- **Primary:** Solid carbon background (`#17181C`), pure white label, `8px` corner radius, `0px 1px 2px rgba(0,0,0,0.1)` elevation. On hover: shifts to `#2A2C33`.
- **Secondary / Tertiary:** Crisp border (`1px solid #D0D5DD`), off-white surface (`#FFFFFF`), charcoal text. On hover: subtle neutral shift to `#F6F7F9`.

### Chips & Suggested Prompts
- **Prompt Pills:** Pill-shaped (`9999px`), `1px solid #E4E7EC`, background `#FFFFFF`, text `#2A2C33`. On hover: border transitions to `#17181C`.
- **Telemetry Chips:** Monospace text, capsule-shaped, `#F6F7F9` background, muted graphite typography (`#525766`), zero outline.

### Input Fields & Search Prompt
- **Chat Prompt Stage:** Large card container with a pure white surface (`#FFFFFF`), `1px solid #D0D5DD`, rounded `12px`. Features internal monospace character counters, disclaimer text, and an integrated primary action button. 
- **Active Focus:** Focus state transitions to `1px solid #17181C` with zero chromatic glow.

### Cards & Fact Blocks
- **FAQ Fact Cards:** Enclosed in `1px solid #E4E7EC`, white background, `8px` radius. Divided internally by `1px solid #F6F7F9` separators. Monospace header tags indicate source authority (e.g., `SOURCE: SID / KIM 2024`).

### Financial Lists & Data Tiers
- **Metric Rows:** Alternating data rows separated by hairline borders. Fund names set in Plus Jakarta Sans medium; NAV values, expense ratios, and alpha/beta statistics aligned right in JetBrains Mono.

### Checkboxes & Segment Controls
- **Segment Controls:** Enclosed pill track in `#F6F7F9` with pure white active segments defined by hairline outlines and subtle micro-shadows.
- **Checkboxes:** `4px` radius, `1px solid #D0D5DD`, filling to `#17181C` upon selection with a crisp white tick mark.